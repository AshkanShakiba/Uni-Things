public class Test{
	public static void main (String [] args){
		/*System.out.println("salam");
		System.out.print("CHETORI?");
		System.out.println("?!");*/
		
		//System.out.printf("%s\n%s","salam","khoobi?");
		
		/*int a = 5;
		int b = 6;
		int sum = a+b;
		System.out.println(sum);*/
		
		/*int p = 6, r = 1, q = 2, w = 4, x = 3, y = 5;
		int z = p * r % q + w / x - y;
		System.out.println(z);*/
		
		/*int a = 6, x = 1, b = 4, c = 5;
		int y = a * x * x + b * x + c;
		System.out.println(y);*/
		
		/*int a = 6, x = 1, b = 4, c = 5;
		int y = a * x / c + b * x + c; //right to left!!
		System.out.println(y);*/
		
		/*int a = 11;
		int b = 11;
		if (a == b)
			System.out.printf("%d == %d\n", a, b);
		if (a != b)
			System.out.printf("%d != %d\n", a, b);
		if (a <= b)
			System.out.printf("%d <= %d\n", a, b);
		if (a >= b)
			System.out.printf("%d >= %d\n", a, b);
		if (a < b)
			System.out.printf("%d < %d\n", a, b);
		if (a > b)
			System.out.printf("%d > %d\n", a, b);*/
		
		/*char gradeRank;
		//float studentGrade = (float)18.6;
		//float studentGrade = 18.6f;
		double studentGrade = (float)9.0;
		
		if (studentGrade >= 17){
			gradeRank = 'A';
			System.out.println("Student grade is A!");
		}else if (studentGrade >= 15){
			gradeRank = 'B';
			System.out.println("Student grade is B!");
		}else if (studentGrade >= 12){
			gradeRank = 'C';
			System.out.println("Student grade is C!");
		}else if (studentGrade >= 10){
			gradeRank = 'D';
			System.out.println("Student grade is D!");
		}else {
			System.out.println("Student is Failed!");
		}*/
		
		/*int c = 5;
		
		System.out.println(c);
		System.out.println(c++);
		System.out.println(c);
		
		c = 5;
		
		System.out.println(c);
		System.out.println(++c);
		System.out.println(c);*/
		
		/*double studentGrade = 15.3;
		System.out.println(studentGrade >= 10 ? "Passed!" : "Failed!");*/
		
		/*for ( int i = 2; i <= 20; i += 3)
			System.out.println(i);*/
		
		/*int total = 0;
		for (int i = 2; i <= 20; total += i, i += 2);
		System.out.println(total);*/
		
		/*int counter = 0;
		do
		{
			System.out.println(counter);
			++counter;
		}while( counter > 1 );
		
		while ( counter > 1 ){
			System.out.println(counter);
			++counter;
		}*/
		
		/*for ( int i = 1; i <= 10; i++){
			if ( i==5 ){
				//break;
				continue;
			}
			System.out.println(i);
		}*/
		
		/*char c = 'B';
		
		switch ( c ) {
			case 'A':
				System.out.println('A');
				break;
			case 'B':
			case 'C':
				System.out.println("B or C");
				break;
			case 'D':
				System.out.println('D');
				break;
			default:
				System.out.println("Any Other Characters");
		}*/
		
		/*int a = 9;
		int b = 12;
		
		//if ( a >= 10 && b == 12)
		//	System.out.printf("a = %d\nb = %d\n", a, b);
		//if ( a++ >= 10 && b == 12)
		//	System.out.printf("a = %d\nb = %d\n", a, b);
		//if ( a >= 10 & ++b == 13)
		//	System.out.printf("a = %d\nb = %d\n", a, b);
		//else
		//	System.out.printf("a = %d\nb = %d\n", a, b);*/
	}
}