import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.util.function.UnaryOperator;

public class AdditionView {
    private AdditionController controller;
    private GridPane view;
    private TextField xField;
    private TextField yField;
    private Label sumLabel;

    public AdditionView(AdditionController controller) {

        this.controller = controller;

        createAndConfigurePane();

        createAndLayoutControls();

        updateModelFromListeners();

        observeModelAndUpdateControls();

    }

    public Parent asParent() {
        return view;
    }

    private void createAndConfigurePane() {
        view = new GridPane();

        ColumnConstraints leftCol = new ColumnConstraints();
        leftCol.setHalignment(HPos.RIGHT);
        leftCol.setHgrow(Priority.NEVER);

        ColumnConstraints rightCol = new ColumnConstraints();
        rightCol.setHgrow(Priority.ALWAYS);

        view.getColumnConstraints().addAll(leftCol, rightCol);

        view.setAlignment(Pos.CENTER);
        view.setHgap(8);
        view.setVgap(16);
        view.setPadding(new Insets(25, 25, 25, 25));
    }

    private void createAndLayoutControls() {
        xField = new TextField();
        configTextFieldForInts(xField);

        yField = new TextField();
        configTextFieldForInts(yField);

        sumLabel = new Label();

        view.addRow(0, new Label("X:"), xField);
        view.addRow(1, new Label("Y:"), yField);
        view.addRow(2, new Label("Sum:"), sumLabel);
    }

    private void configTextFieldForInts(TextField field) {
        field.setPrefWidth(250);
        field.setTextFormatter(new TextFormatter<Integer>(new UnaryOperator<Change>() {
            @Override
            public Change apply(Change c) {
                if (c.getControlNewText().matches("-?\\d*")) {
                    return c;
                }
                return null;
            }
        }));
    }

    private void observeModelAndUpdateControls() {
        controller.getModel().xProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> obs, Number oldX, Number newX) {
                updateIfNeeded(newX, xField);
            }
        });

        controller.getModel().yProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> obs, Number oldY, Number newY) {
                updateIfNeeded(newY, yField);
            }
        });

        sumLabel.textProperty().bind(controller.getModel().sumProperty().asString());
    }

    private void updateIfNeeded(Number value, TextField field) {
        String s = value.toString();
        if (!field.getText().equals(s)) {
            field.setText(s);
        }
    }

    private void updateModelFromListeners() {
        xField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> obs, String oldText, String newText) {
                controller.updateX(newText);
            }
        });

        yField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> obs, String oldText, String newText) {
                controller.updateY(newText);
            }
        });
    }
}